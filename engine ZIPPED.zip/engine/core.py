from __future__ import annotations

from typing import Iterable

from schema import CausalEdge, Context, MatchResult, SimilarIncident, SuggestedRemediation
from engine.memory import EventMemory
from engine.topology import TopologyGraph
from engine.normalizer import EventNormalizer
from engine.shape import ShapeEncoder, ShapeIndex
from engine.reinforcement import RemediationTracker
from engine.causal import CausalChainBuilder


# Canonical look-back window used for BOTH incident indexing and context queries.
# Keeping this constant is critical: the stored signature is encoded over exactly
# this window, so the query must use the same window to produce a comparable shape.
# mode (fast|deep) controls causal reasoning depth, NOT memory recall scope.
INCIDENT_WINDOW_SECONDS: float = 600.0


class ContextEngine:
    """
    Orchestrates all subsystems behind the two-method adapter interface.

    Invariant: memory.ingest_one is ALWAYS called before any topology or
    index side-effects so that alias resolution is consistent throughout.
    """

    def __init__(self) -> None:
        self.memory = EventMemory()
        self.topology = TopologyGraph()
        self.normalizer = EventNormalizer()
        self.shape_encoder = ShapeEncoder()
        self.shape_index = ShapeIndex()
        self.remediation_tracker = RemediationTracker()
        self.causal_builder = CausalChainBuilder(self.topology, self.memory)

        self._pending_incident_window_seconds: float = INCIDENT_WINDOW_SECONDS
        # incident_id → shape.signature, used to look up remediations without
        # re-encoding from raw events at query time (which would risk mismatches)
        self._incident_signatures: dict[str, tuple] = {}
        self._orphaned_remediations: int = 0  # debug counter

    # ── Ingestion ─────────────────────────────────────────────────────────────

    def ingest(self, events: Iterable[dict]) -> None:
        for event in events:
            self._ingest_one(event)

    def _ingest_one(self, event: dict) -> None:
        # Memory first — every downstream call may call memory.resolve()
        self.memory.ingest_one(event)

        kind = event.get("kind", "")
        change = event.get("change", "")

        if kind == "topology":
            if change == "rename":
                old = event.get("old_name") or event.get("from") or ""
                new = event.get("new_name") or event.get("to") or ""
                if old and new:
                    # Use the raw new name, not resolved; memory already updated the
                    # alias map, so resolve(new) == new here for the current canonical
                    self.topology.apply_rename(old, self.memory.resolve(new))
            elif change in ("add_edge", "remove_edge"):
                self.topology.ingest_event(event, self.memory)

        elif kind == "trace":
            self.topology.ingest_event(event, self.memory)

        elif kind == "incident_signal":
            self._index_incident(event)

        elif kind == "remediation":
            self._record_remediation(event)

    def _index_incident(self, event: dict) -> None:
        incident_id = event.get("incident_id") or event.get("id", "")
        if not incident_id:
            return

        anchor_ts = float(event.get("ts", 0))
        anchor_canonical = self.memory.resolve(event.get("service") or "")
        window_secs = self._pending_incident_window_seconds

        raw_window = self.memory.events_in_window(anchor_ts, window_secs)
        # Exclude the incident_signal itself so it doesn't appear as its own cause
        own_id = event.get("id", "")
        window = [e for e in raw_window if e.get("id") != own_id]

        # normalize_window clears the role cache for this call
        normalized = self.normalizer.normalize_window(
            window, anchor_ts, anchor_canonical, self.memory, self.topology
        )
        shape = self.shape_encoder.encode(
            normalized,
            incident_id=incident_id,
            window_start=anchor_ts - window_secs,
            window_end=anchor_ts,
        )
        self.shape_index.add(shape)
        # Store at ingestion time; never regenerate at query time — the stored
        # signature is the canonical reference for remediation lookups
        self._incident_signatures[incident_id] = shape.signature

    def _record_remediation(self, event: dict) -> None:
        incident_id = event.get("incident_id", "")
        sig = self._incident_signatures.get(incident_id)
        if sig is None:
            self._orphaned_remediations += 1
            return
        self.remediation_tracker.record(
            signature=sig,
            action=event.get("action", ""),
            target=event.get("service") or event.get("target") or "",
            outcome=event.get("outcome", "unknown"),
            ts=float(event.get("ts", 0)),
        )

    # ── Query ─────────────────────────────────────────────────────────────────

    def reconstruct_context(self, signal: dict, mode: str = "fast") -> dict:
        # TODO: add (signal.get("id"), mode) cache once profiling shows this
        # is called multiple times per incident in a single request path.

        anchor_ts = float(signal.get("ts", 0))
        anchor_canonical = self.memory.resolve(signal.get("service") or "")
        # Same constant used at index time — mode controls causal depth, not window.
        window_secs = INCIDENT_WINDOW_SECONDS

        raw_window = self.memory.events_in_window(anchor_ts, window_secs)

        # ── related_events: 30 most recent raw events in the window ──────────
        related_events = sorted(raw_window, key=lambda e: -float(e.get("ts", 0)))[:30]

        # ── Encode query shape (always fresh; see TODO above for caching) ─────
        normalized = self.normalizer.normalize_window(
            raw_window, anchor_ts, anchor_canonical, self.memory, self.topology
        )
        query_sig = self.shape_encoder.encode(
            normalized,
            incident_id="__query__",
            window_start=anchor_ts - window_secs,
            window_end=anchor_ts,
        ).signature

        # ── Similar past incidents ───────────────────────────────────────────
        matches: list[MatchResult] = self.shape_index.query(query_sig, top_k=5)
        similar_past_incidents: list[SimilarIncident] = [
            SimilarIncident(
                past_incident_id=m.incident_id,
                similarity=m.similarity,
                rationale=(
                    f"behavioral match: {m.match_type}, "
                    f"{m.matched_positions} matched positions of "
                    f"{len(m.shape.signature)} in past signature"
                ),
            )
            for m in matches
        ]

        # ── Causal chain ─────────────────────────────────────────────────────
        causal_chain: list[CausalEdge] = self.causal_builder.build(
            signal, mode=mode
        )

        # ── Suggested remediations ───────────────────────────────────────────
        # Per action: keep the highest weighted confidence across all similar incidents.
        # Weighted confidence = match_similarity × smoothed_success_rate.
        action_best: dict[str, tuple[float, str, str]] = {}
        for m in matches:
            past_sig = self._incident_signatures.get(m.incident_id)
            if past_sig is None:
                continue
            for action, rate, samples, target in self.remediation_tracker.best_actions(
                past_sig, top_k=3
            ):
                wc = round(m.similarity * rate, 4)
                outcome_str = (
                    f"resolved {int(round(rate * samples))}/{samples} cases"
                    if samples > 0
                    else "no historical data"
                )
                if action not in action_best or wc > action_best[action][0]:
                    action_best[action] = (wc, target, outcome_str)

        suggested_remediations: list[SuggestedRemediation] = sorted(
            [
                SuggestedRemediation(
                    action=action,
                    target=target,
                    historical_outcome=outcome_str,
                    confidence=wc,
                )
                for action, (wc, target, outcome_str) in action_best.items()
            ],
            key=lambda r: -r["confidence"],
        )[:3]

        # ── Overall confidence ───────────────────────────────────────────────
        max_sim = matches[0].similarity if matches else 0.0
        top_remed = suggested_remediations[0]["confidence"] if suggested_remediations else 0.0
        avg_causal = (
            sum(e["confidence"] for e in causal_chain) / len(causal_chain)
            if causal_chain else 0.0
        )
        confidence = round(
            min(1.0, 0.4 * max_sim + 0.3 * top_remed + 0.3 * avg_causal), 4
        )

        # ── Explain ──────────────────────────────────────────────────────────
        explain = _build_explain(
            anchor_canonical, matches, causal_chain, suggested_remediations
        )

        return Context(
            related_events=related_events,
            causal_chain=causal_chain,
            similar_past_incidents=similar_past_incidents,
            suggested_remediations=suggested_remediations,
            confidence=confidence,
            explain=explain,
        )

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def close(self) -> None:
        pass  # placeholder for future cleanup (e.g., persist index to disk)


# ── Module-level helper (no self needed) ─────────────────────────────────────

def _build_explain(
    anchor_canonical: str,
    matches: list[MatchResult],
    causal_chain: list[CausalEdge],
    remediations: list[SuggestedRemediation],
) -> str:
    svc = anchor_canonical or "unknown service"

    if not matches:
        return (
            f"No historically similar incidents found for {svc}. "
            "The event window has been analysed but no pattern match exists "
            "in the index yet."
        )

    top = matches[0]
    match_desc = (
        f"past incident {top.incident_id} "
        f"(similarity {top.similarity:.2f}, {top.match_type} match)"
    )

    upstream_note = ""
    if causal_chain:
        tc = causal_chain[0]
        upstream_note = (
            f" Causal analysis identified: {tc['evidence']} "
            f"(confidence {tc['confidence']:.2f})."
        )

    remed_note = ""
    if remediations:
        r = remediations[0]
        remed_note = (
            f" Top suggested action: '{r['action']}' on {r['target']} "
            f"— {r['historical_outcome']} (confidence {r['confidence']:.2f})."
        )

    return f"Incident on {svc} matches {match_desc}.{upstream_note}{remed_note}"
