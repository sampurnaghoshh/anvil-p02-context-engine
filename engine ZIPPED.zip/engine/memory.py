from __future__ import annotations

import bisect
from collections import defaultdict
from typing import Optional


class EventMemory:
    """
    Append-only event store with:
    - O(log n) time-window queries via bisect on a parallel timestamp index
    - canonical alias map that survives multi-hop service renames
    """

    def __init__(self) -> None:
        self._events: list[dict] = []
        self._ts_keys: list[float] = []           # parallel; always sorted
        self._id_index: dict[str, dict] = {}
        self._alias_map: dict[str, str] = {}      # any historical name -> current canonical
        self._canon_members: dict[str, set[str]] = defaultdict(set)  # canonical -> past names

    # ── Ingestion ─────────────────────────────────────────────────────────────

    def ingest_one(self, event: dict) -> None:
        if event.get("kind") == "topology" and event.get("change") == "rename":
            old = event.get("old_name") or event.get("from")
            new = event.get("new_name") or event.get("to")
            if old and new:
                self._apply_rename(old, new)

        ts = float(event.get("ts", 0.0))
        pos = bisect.bisect_right(self._ts_keys, ts)
        self._events.insert(pos, event)
        self._ts_keys.insert(pos, ts)

        eid = event.get("id")
        if eid:
            self._id_index[eid] = event

    # ── Alias management ──────────────────────────────────────────────────────

    def _apply_rename(self, old_name: str, new_name: str) -> None:
        # Walk the chain: if old_name is itself an alias, find its current canonical
        canonical_old = self._alias_map.get(old_name, old_name)
        # Collect every name that resolved to canonical_old (including itself)
        members = self._canon_members.pop(canonical_old, set())
        members.add(canonical_old)
        for name in members:
            self._alias_map[name] = new_name
        self._canon_members[new_name].update(members)

    def resolve(self, name: str) -> str:
        """Return the current canonical name for any historical service name."""
        return self._alias_map.get(name, name)

    # ── Temporal queries ──────────────────────────────────────────────────────

    def events_in_window(self, end_ts: float, seconds_before: float) -> list[dict]:
        """Return all events whose ts falls in [end_ts - seconds_before, end_ts]."""
        start_ts = end_ts - seconds_before
        lo = bisect.bisect_left(self._ts_keys, start_ts)
        hi = bisect.bisect_right(self._ts_keys, end_ts)
        return self._events[lo:hi]

    def get_by_id(self, event_id: str) -> Optional[dict]:
        return self._id_index.get(event_id)

    def __len__(self) -> int:
        return len(self._events)
