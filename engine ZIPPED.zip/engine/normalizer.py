from __future__ import annotations

import hashlib
import re
from typing import TYPE_CHECKING

from schema import NormalizedEvent

if TYPE_CHECKING:
    from engine.memory import EventMemory
    from engine.topology import TopologyGraph

# Strips: bare numbers, version strings, UUIDs, IPv4[:port], hex hashes/span IDs
_VOLATILE_RE = re.compile(
    r"\b(?:"
    r"v\d+(?:\.\d+){1,3}"                                                   # v1.2.3
    r"|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"      # UUID
    r"|\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?::\d+)?"                        # IPv4
    r"|[a-f0-9]{32,}"                                                        # hex hash
    r"|\d+"                                                                  # number
    r")\b",
    re.IGNORECASE,
)

# Maps upper-bound seconds -> delta bucket integer (-3 … +3)
_DELTA_BOUNDS: list[tuple[float, int]] = [
    (-120.0, -3),
    (-30.0,  -2),
    (-5.0,   -1),
    (5.0,     0),
    (30.0,    1),
    (120.0,   2),
]


def _delta_bucket(delta_s: float) -> int:
    for bound, bucket in _DELTA_BOUNDS:
        if delta_s <= bound:
            return bucket
    return 3


def _scrub(text: str, service_name: str) -> str:
    """Replace the canonical service name then strip all volatile tokens.
    Invariance holds when the event's own service appears in the message.
    Cross-service name references in text are a known gap (would need full alias set).
    """
    if service_name:
        text = text.replace(service_name, "_SVC_")
    return _VOLATILE_RE.sub("_", text).strip()


def _payload_hash(kind: str, event: dict, canonical_service: str) -> str:
    """
    Short rename-invariant hash of the event's semantic content.
    Never includes service names, version strings, IDs, or raw numeric values.
    """
    parts = [kind]

    if kind == "log":
        parts.append(event.get("level", ""))
        parts.append(_scrub(event.get("message", ""), canonical_service))

    elif kind == "metric":
        name = event.get("metric_name", "")
        val = float(event.get("value") or 0.0)
        thresh = event.get("threshold")
        if thresh:
            ratio = val / float(thresh)
            bracket = "CRITICAL" if ratio > 2.0 else "HIGH" if ratio > 1.0 else "NORMAL"
        else:
            bracket = "_"
        parts += [name, bracket]

    elif kind == "deploy":
        # Version is drift-prone — record only that a deploy occurred.
        # TODO: if signature matching is too coarse, derive version_bump_type
        # (major/minor/patch) from semver delta and add it here.
        parts.append("deploy")

    elif kind == "trace":
        parts.append(event.get("status", ""))
        dur = float(event.get("duration_ms") or 0.0)
        if dur > 5000:
            latency = "CRITICAL"
        elif dur > 1000:
            latency = "SLOW"
        elif dur > 200:
            latency = "MODERATE"
        else:
            latency = "OK"
        parts.append(latency)

    elif kind == "topology":
        parts.append(event.get("change", ""))

    elif kind == "incident_signal":
        parts.append(event.get("severity", ""))
        parts.append(_scrub(event.get("description", ""), canonical_service))

    elif kind == "remediation":
        parts.append(_scrub(event.get("action", ""), canonical_service))

    return hashlib.md5("|".join(parts).encode()).hexdigest()[:12]


class EventNormalizer:
    """Stateless; all mutable state lives in EventMemory and TopologyGraph."""

    def normalize_event(
        self,
        event: dict,
        anchor_ts: float,
        anchor_canonical: str,
        memory: "EventMemory",
        topology: "TopologyGraph",
    ) -> NormalizedEvent:
        canonical = memory.resolve(event.get("service") or "")
        role = topology.role_of(canonical, anchor_canonical) if canonical else "unknown"
        return NormalizedEvent(
            original_id=event.get("id", ""),
            kind=event.get("kind", ""),
            ts=event["ts"],
            role=role,
            canonical_service=canonical,
            delta_bucket=_delta_bucket(event["ts"] - anchor_ts),
            payload_hash=_payload_hash(event.get("kind", ""), event, canonical),
        )

    def normalize_window(
        self,
        events: list[dict],
        anchor_ts: float,
        anchor_canonical: str,
        memory: "EventMemory",
        topology: "TopologyGraph",
    ) -> list[NormalizedEvent]:
        """
        Sort by ts, clear the per-call role cache, return normalized events.
        Cache cleared here covers both this call and any subsequent causal
        traversal within the same reconstruct_context invocation.
        """
        topology.clear_role_cache()
        return [
            self.normalize_event(e, anchor_ts, anchor_canonical, memory, topology)
            for e in sorted(events, key=lambda e: e["ts"])
            if _is_incident_relevant(e)
        ]
